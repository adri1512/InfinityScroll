import 'package:flutter/material.dart';
import 'package:gyphi/my_app.dart';

void main() {
  runApp(MyApp());
}
