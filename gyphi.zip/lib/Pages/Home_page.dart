import 'package:flutter/material.dart';

import 'package:gyphi/Models/Model_Gifs.dart';
import 'package:gyphi/Providers/Gif_Provider.dart';
import 'package:gyphi/Widgets/listGifs.dart';

class MyHomeApp extends StatefulWidget {
  const MyHomeApp({Key? key, required this.title}) : super(key: key);

  final String title;
  @override
  State<MyHomeApp> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomeApp> {
  late Future<List<ModelGifs>> _listadoGifs;
  late ScrollController _scrollController;
  List<ModelGifs> _loadedGifs = [];
  int _currentPage = 1;

  @override
  void initState() {
    super.initState();
    final getprovider = new GifProvider();
    _listadoGifs = getprovider.getGifs();
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _loadMoreGifs();
    }
  }

  void _loadMoreGifs() async {
    final getprovider = new GifProvider();
    final newGifs = await getprovider.getGifs();
    setState(() {
      _loadedGifs.addAll(newGifs);
      _currentPage++;
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: FutureBuilder(
        future: _listadoGifs,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            _loadedGifs = snapshot.data as List<ModelGifs>;
            return GridView.count(
              controller: _scrollController,
              crossAxisCount: 2,
              children: listGifs(_loadedGifs),
            );
          } else {
            print(snapshot.error);
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
